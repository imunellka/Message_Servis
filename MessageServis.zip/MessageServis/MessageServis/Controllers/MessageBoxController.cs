using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection.Metadata;
using System.Text;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using MessageServis.Models;
using Microsoft.AspNetCore.Mvc.ViewFeatures;
using System.Text.Json;
using System.Threading.Channels;
using Microsoft.VisualStudio.Web.CodeGeneration.Contracts.Messaging;

namespace MessageServis.Controllers
{
    [Route("/api/[controller]")]
    public class MessageBoxController : Controller
    {
        //Список сообщений.
        private List<Messages> messagesBox = new();
        
        //Список пользователей.
        private List<User> users = new();
        
        //Экземпляр рандома.
        private Random rnd = new Random();
        
        //Список гласных.
        private string[] vowels = new string[] {"a", "e", "y", "u", "i", "o"};

        //Список согласных.
        private string[] consonants = new string[]
        {
            "q", "w", "r", "t", "p", "s", "d", "f", "g", "h",
            "j", "k", "l", "z", "x", "c", "v", "b", "n", "m"
        };

        //Список для букв.
        private string[] letters = new string[]
        {
            "q", "w", "r", "t", "p", "s", "d", "f", "g", "h",
            "j", "k", "l", "z", "x", "c", "v", "b", "n", "m",
            "a", "e", "y", "u", "i", "o"
        };

        
        //Список для генерации текста.
        private string[] dictionary = new string[]
        {
            "q", " ", "w", "r", "t", "p", "s", " ", "d", "f", "g", "h",
            "j", "k", "l", "z", "x", " ", "c", "v", "b", "n", "m", ", ",
            "a", "e", " ", "y", "u", " ", "i", "o", ". ", " ", "? ", "! "

        };

        /// <summary>
        /// Получить пользователя по его email.
        /// </summary>
        /// <param name="email">email</param>
        /// <returns>json обьект</returns>
        [HttpGet("users/email/{email}")]
        public IActionResult GetUserByEmail(string email)
        {
            DeserializeUsers();
            var user = users.FirstOrDefault(p => p.Email == email);
            if (user == null)
            {
                return NotFound();
            }
            return Ok(user);
        }

        /// <summary>
        /// Получить сообщения между двумя пользователями.
        /// </summary>
        /// <param name="senderEmail">Отправитель</param>
        /// <param name="recieverEmail">Получатель</param>
        /// <returns>json обьект</returns>
        [HttpGet("message/by/from/{senderEmail}/{recieverEmail}")]
        public IActionResult GetMessageByTwoEmail(string senderEmail, string recieverEmail)
        {
            DeserializeMessage();
            var message = messagesBox.FindAll(m => m.SenderId == senderEmail && m.ReceiverId == recieverEmail);

            if (message == null)
            {
                return NotFound();
            }

            return Ok(message);
        }


        /// <summary>
        /// Получить сообщения по отправителю.
        /// </summary>
        /// <param name="senderEmailOnly">отправитель</param>
        /// <returns>json обьект</returns>
        [HttpGet("message/by/{senderEmailOnly}")]
        public IActionResult GetMessageBySender(string senderEmailOnly)
        {
            DeserializeMessage();
            var message = messagesBox.Where(m => m.SenderId == senderEmailOnly);
            if (message.Count()==0)
            {
                return NotFound();
            }
            return Ok(message);
        }

        /// <summary>
        /// Получить сообщения по получателю.
        /// </summary>
        /// <param name="recieverEmailOnly">получатель</param>
        /// <returns>json обьект</returns>
        [HttpGet("message/from/{recieverEmailOnly}")]
        public IActionResult GetMessageByReceiver(string recieverEmailOnly)
        {
            DeserializeMessage();
            var message = messagesBox.Where(m => m.ReceiverId == recieverEmailOnly);
            if (message.Count()==0)
            {
                return NotFound();
            }
            return Ok(message);
        }


        /// <summary>
        /// Получить информацию о всех пользователях с параметрами.
        /// </summary>
        /// <param name="limit">количество пользователей</param>
        /// <param name="offset">индекс (с 1) - точка отсчета пользователей</param>
        /// <returns>json обьект</returns>
        [HttpGet("/users/{limit}/{offset}")]
        public IActionResult GetAllUsers(int limit, int offset)
        {
            DeserializeUsers();
            if (users == null)
            {
                return NotFound();
            }
            if (limit <= 0 || offset < 0)
            {
                return BadRequest("Некорректные данные");
            }
            if (users.Count()< offset)
            {
                return NotFound("Точка отсчета больше длины массива");
            }
            var usersAnswer = new List<User>();
            for (int i = offset-1; i < users.Count; i++)
            {
                usersAnswer.Add(users[i]);
                limit--;
                if (limit == 0) break;
            }
            return Ok(usersAnswer);
        }

        
        /// <summary>
        /// Получить список пользователей.
        /// </summary>
        /// <returns>список пользователей</returns>
        [HttpGet]
        public IEnumerable<User> Get()
        {
            DeserializeUsers();
            return users;
        }

        /// <summary>
        /// Заполнить массива рандомными элементами списка.
        /// </summary>
        /// <returns>json обьекты</returns>
        [HttpPost("users/initialize")]
        public IActionResult Initialize()
        {
            string newName = "";
            users = new List<User>();
            messagesBox = new List<Messages>();
            var count = rnd.Next(3, 12);
            for (var i = 0; i < count; i++)
            {
                newName = GenerateName(rnd.Next(6, 10));
                users.Add(new User(newName, GenerateEmail(newName)));
            }
            var messagecount = rnd.Next(7, 15);
            for (var i = 0; i < messagecount; i++)
            {
                var (sender, receiver) = GetTwoBuddy();
                messagesBox.Add(new Messages(GenerateText(rnd.Next(5, 15)),
                    GenerateText(rnd.Next(20, 40)), sender.Email, receiver.Email));
            }
            SaveData();
            return Ok();
        }

        /// <summary>
        /// Генерация текста.
        /// </summary>
        /// <param name="count">длина</param>
        /// <returns>текст</returns>
        private string GenerateText(int count)
        {
            StringBuilder text = new StringBuilder();
            while (text.Length < count)
            {
                text.Append(dictionary[rnd.Next(0, dictionary.Length)]);
            }
            return text.ToString();
        }

        /// <summary>
        /// Получение двух рандомных собеседников.
        /// </summary>
        /// <returns>Собеседники</returns>
        private (User, User) GetTwoBuddy()
        {
            int firstUser = rnd.Next(0, users.Count);
            int secondUser = firstUser;
            while (firstUser == secondUser)
                secondUser = rnd.Next(0, users.Count);
            return (users[firstUser], users[secondUser]);
        }

        /// <summary>
        /// Генерация имени.
        /// </summary>
        /// <param name="size">длина</param>
        /// <returns>имя</returns>
        private string GenerateName(int size)
        {
            StringBuilder userName = new StringBuilder();
            while (userName.Length < size)
            {
                bool firstVowel = rnd.Next(0, 2) == 0 ? true : false;
                if (firstVowel)
                {
                    userName.Append(vowels[rnd.Next(0, vowels.Length)]);
                    userName.Append(consonants[rnd.Next(0, consonants.Length)]);
                }
                else
                {
                    userName.Append(consonants[rnd.Next(0, consonants.Length)]);
                    userName.Append(vowels[rnd.Next(0, vowels.Length)]);
                }
            }

            if (size % 2 != 0) userName.Remove(userName.Length - 1, 1);
            userName[0] = char.ToUpper(userName[0]);
            return userName.ToString();
        }


        /// <summary>
        /// Генерация почты.
        /// </summary>
        /// <param name="size">длина</param>
        /// <returns>почта</returns>
        private string GenerateEmail(string name)
        {
            StringBuilder email = new StringBuilder(name);
            int i = 0;
            while (i++ < 4)
            {
                email.Append(letters[rnd.Next(0, letters.Length)]);
            }
            i = 0;
            email.Append("@");
            while (i++ < 4)
            {
                email.Append(letters[rnd.Next(0, letters.Length)]);
            }
            email.Append(".");
            i = 0;
            while (i++ < 2)
            {
                email.Append(letters[rnd.Next(0, letters.Length)]);
            }
            return email.ToString();
        }
        

        
        /// <summary>
        /// Добавить пользователя в список.
        /// </summary>
        /// <param name="userName">Имя пользователя</param>
        /// <param name="userEmail">Почта пользователя</param>
        /// <returns>json обьект</returns>
        [HttpPost("/AddUser/{userName}/{userEmail}")]
        public IActionResult AddMessage(string userName, string userEmail)
        { 
            DeserializeUsers();
            if (users.Where(x=> x.Email==userEmail).Count()!=0)
            {
                return BadRequest("Пользователь с таким email уже есть в системе.");
            }
            users.Add(new User(userName, userEmail));
            SaveData();
            return Ok("save successfully");
        }
        
        
        /// <summary>
        /// Добавление нового сообщения.
        /// </summary>
        /// <param name="senderEmail"></param>
        /// <param name="receiverEmail"></param>
        /// <param name="subject"></param>
        /// <param name="message"></param>
        /// <returns></returns>
        [HttpPost("/AddMessage/{senderEmail}/{receiverEmail}/{subject}/{message}")]
        public IActionResult AddMessage(string senderEmail, string receiverEmail,string subject, string message)
        { 
            DeserializeUsers();
            DeserializeMessage();
            var senderTrue = users.Where(x => x.Email == senderEmail);
            var receiverTrue = users.Where(x => x.Email == receiverEmail);
            if (senderTrue.Count() == 0 || receiverTrue.Count() == 0)
            {
                return NotFound("We can't find this users");
            }
            messagesBox.Add(new Messages(subject, message, senderEmail, receiverEmail));
            SaveData();
            return Ok("save successfully");
        }
            
        
        
        /// <summary>
        /// Получение списка пользователей из файла.
        /// </summary>
        private void DeserializeUsers()
        {
            var usersText = System.IO.File.ReadAllText("users.json", Encoding.Default);
            users = JsonSerializer.Deserialize<List<User>>(usersText);
        }

        /// <summary>
        /// Получение списка сообщений из файла.
        /// </summary>
        private void DeserializeMessage()
        {
            var messageText = System.IO.File.ReadAllText("messages.json", Encoding.Default);
            messagesBox = JsonSerializer.Deserialize<List<Messages>>(messageText);
        }

        /// <summary>
        /// Сохранение данных в json файл.
        /// </summary>
        private void SaveData()
        {
            try
            {
                users.Sort((a, b) => string.Compare(a.Email, b.Email, StringComparison.Ordinal));
                var usersWr = JsonSerializer.Serialize(users);
                var messageWr = JsonSerializer.Serialize(messagesBox);
                using (var fs = new FileStream("users.json", FileMode.Create, FileAccess.Write))
                {
                    using (var sw = new StreamWriter(fs, Encoding.Default))
                    {
                        sw.Write(usersWr);
                    }
                }
                using (var fs = new FileStream("messages.json", FileMode.Create, FileAccess.Write))
                {
                    using (var sw = new StreamWriter(fs, Encoding.Default))
                    {
                        sw.Write(messageWr);
                    }
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
        }
    }
}