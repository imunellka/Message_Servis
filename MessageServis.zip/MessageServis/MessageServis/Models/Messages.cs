using System;
using System.ComponentModel.DataAnnotations;
using System.Runtime.Serialization;
#pragma warning disable

namespace MessageServis.Models
{
    //Модель сообщения
    [Serializable]
    [DataContract]
    public class Messages
    {
        //Тема письма.
        [Required] 
        [DataMember]
        public string Subject { get; set; }
        [Required] 
        [DataMember]
        // Текст письма.
        public string Message { get; set; }
        
        //email отправителя.
        [Required] 
        [DataMember]
        public string SenderId { get; set; }
        [Required] 
        [DataMember]
        //email получателя.
        public string ReceiverId { get; set; }

        public Messages(string subject, string message,string senderId,string receiverId)
        {
            Subject = subject;
            Message = message;
            SenderId = senderId;
            ReceiverId = receiverId;

        }
    }
}