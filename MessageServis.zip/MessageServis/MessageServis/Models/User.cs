using System;
using System.ComponentModel.DataAnnotations;
using System.Runtime.Serialization;
#pragma warning disable

namespace MessageServis.Models
{
    //Модель пользователя сервиса.
    [Serializable]
    [DataContract]
    public class User
    {
        //Имя пользователя.
        [Required] 
        [DataMember]
        public string UserName { get; set; }
        
        //Почта пользователя.
        [DataMember]
        [Required] 
        public string Email { get; set; }

        public User(string userName, string email)
        {
            UserName = userName;
            Email = email;
        }
    }
}